# netfox.internals

Shared utilities for [netfox] addons. Not intended for standalone usage.

Instead, check out the other addons in the [netfox] repository.


[netfox]: https://github.com/foxssake/netfox
