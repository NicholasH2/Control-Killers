# StateSynchronizer NPC example

This example demonstrates the usage of StateSynchronizer. All the NPCs are
simulated on the server, in the tick loop ( as opposed to the rollback loop ).

Each NPC wanders around, taking a periodical break to look around.

