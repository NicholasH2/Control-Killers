# Input gathering example

An example game demonstrating advanced input gathering techniques, including
continuous and one-off inputs.

