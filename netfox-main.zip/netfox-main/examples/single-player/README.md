# Single player example

A simple demo game, completely lacking multiplayer functionality, to serve as a
baseline for comparisons.

To edit and/or run, open the Godot project in the repository root, and open the
scene in this directory.

Compare it with:
* [Simple example](../multiplayer-simple)
* [Example with netfox](../multiplayer-netfox)

