# Rollback NPC example

A demo game, demonstrating how to implement server-controlled NPCs that
participate in rollback.

With `RollbackSynchronizer` supporting no input, NPCs ( and other nodes without
input ) can be built the same way as e.g. player nodes.

To edit and/or run, open the Godot project in the repository root, and open the
scene in this directory.

